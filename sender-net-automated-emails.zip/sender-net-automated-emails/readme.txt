
=== Sender.net Automated Emails ===

Contributors: Sender.net
Tags: sender.net, abandoned cart, cart recovery, email marketing software, email marketing automation, newsletter, automated, emails, conversion, push, notification, subscription, forms
Author URI: https://www.sender.net/
Requires at least: 1.3
Tested up to: 4.9.8
Stable tag: master
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


== Description ==

This is the official documentation for Sender.net’s WordPress / WooCommerce v1.0.3 integration plugin.

This plugin doesn’t require WooCommerce  to be installed, you can use it as a separate product. However, to use most of the features, it’s necessary to have Woocommerce installed.

== KEY FEATURES ==

Subscription forms
Web-Push Notifications
Auto-subscription of new users
Cart tracking
Abandoned cart reminder using Sender.net’s automation
Quick product import to your campaigns
Guest cart capture
Converted cart tracking

== Changelog ==

= 1.0.5 =
Bug fixes

= 1.0.4 =
Added CURL for making requests if file_get_contents is not available

= 1.0.0 =
Initial release
