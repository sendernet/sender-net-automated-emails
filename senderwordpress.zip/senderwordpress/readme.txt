
=== Sender.net WordPress / WooCommerce integration plugin ===
Contributors: Sender.net
Tags: sender.net, abandoned cart, cart recovery, email marketing software, email marketing automation, newsletter 
Author URI: https://www.sender.net/
Requires at least: 1.3
Tested up to: 4.8.2
Stable tag: master
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


== Description ==

Sender.net - WordPress/Woocommerce integration plugin

Adds Sender.net forms and push notifications to your wordpress site,
enables new users auto subscribe, which can be used for welcome email automations etc.

If you have WooCommerce plugin installed it allows you to capture registered / guest users
carts and emails, enables abandoned cart feature, which can start cart automated workflows.

Also enables easy product import when creating email via Sender.net template creator.


== Installation ==

N/A

== Screenshots ==

N/A

== Changelog ==

= 1.0.3 =
* Changed form widget description
* Fixed converted carts name
* Added uninstall.php to handle plugin deletion

= 1.0.2 =
* Added debug logging

= 1.0.1 =
* Minor bug fixes

= 1.0.1 =
* Initial release.
* Beta version.

